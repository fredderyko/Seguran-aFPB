<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Segurança</title>
</head>
<body>
	<center>
		<h1>SEGURANÇA NA WEB</h1>
		<h3>Login</h3>
		<form id="form-login" action="login.php" method="POST">
			Login: <input type="text" name="login"><br>
			Senha: <input type="password" name="senha"><br><br>
			<input type="submit" name="entrar" value="Entrar">
		</form>
	</center>
</body>
</html>